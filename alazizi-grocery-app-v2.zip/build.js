const fs = require('fs');
const path = require('path');
const src = path.join(__dirname, 'www');
if (!fs.existsSync(src)) throw new Error('www directory missing');
console.log('Web app is ready in www/.');
