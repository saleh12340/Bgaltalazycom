const fs=require('fs'); if(!fs.existsSync('www/index.html')) throw new Error('www/index.html not found'); console.log('Web app ready for Capacitor build');
