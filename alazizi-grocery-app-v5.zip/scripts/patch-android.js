const fs=require('fs');
const path='android/app/src/main/AndroidManifest.xml';
if(!fs.existsSync(path)) throw new Error('AndroidManifest.xml not found');
let s=fs.readFileSync(path,'utf8');
const perms=[
  '<uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_CONNECT" />',
  '<uses-permission android:name="android.permission.BLUETOOTH_SCAN" android:usesPermissionFlags="neverForLocation" />'
];
for(const p of perms){ if(!s.includes(p)) s=s.replace('<application',p+'\n    <application'); }
fs.writeFileSync(path,s);
console.log('Android Bluetooth permissions patched');
