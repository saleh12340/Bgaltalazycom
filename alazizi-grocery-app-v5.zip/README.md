# بقالة العزي للمواد الغذائية — V5

نسخة Android/Capacitor محسنة لإدارة الفواتير والحسابات والمخزون والمصروفات والملاحظات والتقارير.

## الطباعة الحرارية
- Bluetooth SPP عبر ESC/POS الخام.
- اختيار 58mm أو 80mm.
- طلب صلاحية BLUETOOTH_CONNECT في Android 12+.
- قائمة بالطابعات المقترنة + إدخال MAC يدوياً.
- اختبار طباعة.

## PDF
- إنشاء PDF بصورة عالية الوضوح باستخدام الخط العربي المضمّن.
- حفظ الملف داخل Documents.
- فتح PDF بتطبيق الهاتف، مشاركة الملف، وطباعة PDF عبر نظام Android.

## GitHub Actions
ارفع ZIP واحداً فقط مع `android.yml` الموجود في `.github/workflows` ثم شغّل Workflow: **Build Android APK V5**.
