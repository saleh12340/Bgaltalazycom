const fs=require('fs');
if(!fs.existsSync('www/index.html')) throw new Error('www/index.html not found');
const html=fs.readFileSync('www/index.html','utf8');
if(!html.includes('ThermalPrinter')) throw new Error('Thermal printer integration missing');
if(!html.includes('createPdfFile')) throw new Error('PDF integration missing');
console.log('V5 web app validation passed');
